export const categoriesData = [
  {
    id: 0,
    name: "Exercise",
    description: "12 Task",
    image: require("../assets/woman1.png"),
  },
  {
    id: 1,
    name: "Study",
    description: "12 Task",
    image: require("../assets/woman.png"),
  },
  {
    id: 2,
    name: "Exercise",
    description: "12 Task",
    image: require("../assets/woman1.png"),
  },
  {
    id: 3,
    name: "Study",
    description: "12 Task",
    image: require("../assets/woman.png"),
  },
];
