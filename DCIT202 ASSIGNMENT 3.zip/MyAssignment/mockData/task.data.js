export const taskData = [
  {
    id: 0,
    name: "Mobile App Development",
  },
  {
    id: 1,
    name: "Web Development",
  },
  {
    id: 2,
    name: "Push Ups",
  },
];
